-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 29. Mrz 2020 um 20:40
-- Server-Version: 10.4.11-MariaDB
-- PHP-Version: 7.4.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `cr11_florian_shelter`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `animals`
--

CREATE TABLE `animals` (
  `id_animals` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `image` varchar(400) DEFAULT NULL,
  `description` varchar(500) DEFAULT NULL,
  `age` smallint(6) DEFAULT NULL,
  `hobbies` varchar(200) DEFAULT NULL,
  `available` date DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `fk_shelter` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `animals`
--

INSERT INTO `animals` (`id_animals`, `name`, `image`, `description`, `age`, `hobbies`, `available`, `status`, `fk_shelter`) VALUES
(1, 'dusty', 'https://media11.s-nbcnews.com/j/MSNBC/Components/Video/201906/OLDDOG_THUMBNAIL.focal-760x428.jpg', 'Für Dusty wünschen wir uns ein Zuhause bei ruhigen, geduldigen Menschen, die ihm Zeit geben sich in Ruhe an sie zu gewöhnen. Idealerweise leben seine neuen Besitzer in ruhiger Umgebung, gerne mit Haus und Garten. Er fährt brav mit dem Auto mit und kann auch mehrere Stunden alleine bleiben. Andere Tiere und Kinder sollten nicht im selben Haushalt leben. Dusty hat bei uns zwar einen Hundefreund und mag Hunde prinzipiell auch, allerdings braucht er auch hier Zeit, um sich in Ruhe mit dem Hund anfre', 9, 'playing ball', '2020-02-02', 'old', 1),
(2, 'pedro', 'https://www.greymuzzle.org/sites/default/files/blogs/images/Stock_Old_Golden_Blog.jpg', 'Ema ist eine kastrierte Staffordshire Terrier-Hündin.\r\n		Menschen gegenüber ist sie anfangs etwas schüchtern und braucht ihre Zeit , bis sie jemandem ihr Vertrauen schenkt. Bei anderen Hunden entscheidet die Sympathie.\r\n		Sie ist eine lustige und verspielte Hündin, die noch Erziehung braucht.\r\n		Die hübsche Dame wird jedoch auch leicht gestresst, verbeißt sich dann in Gegenstände (bei uns v.a. in die Gittertür im Zwinger) und schreit. Sie sucht daher ein Zuhause in ruhiger Umgebung ohne Kinder u', 10, 'plaing ball', '2020-06-06', 'old', 2),
(3, 'zeus', 'https://s7d2.scene7.com/is/image/TWCNews/0613_lockhart_animalshelterdogpng', 'Zeus ist ein sensibler American Staffordshire Terrier-Rüde. Bei Menschen ist Zeus sehr unsicher und braucht daher eine Kennenlernzeit; zu Kindern wird Zeus nicht vergeben. Der kastrierte Rüde versteht sich gut mit Hündinnen und mit Katzen, verteidigt jedoch sein Spielzeug gegenüber anderen Tieren. Laut Angaben der Vorbesitzer fährt er brav im Auto und auch in den Öffis mit. Außerdem geht Zeus brav an der Leine, ist stubenrein und konnte bei den Vorbesitzern bereits alleine bleiben. Da Zeus das G', 10, 'palying ball', '2020-04-04', 'old', 1),
(4, 'Butterkeks', 'https://einfachtierisch.de/media/cache/article_main_image/cms/2018/04/Katze-sitzt-vor-Kabel-Shutterstock-OKcamera.jpg?464838', 'Butterkeks kam 2016 als verwilderte Hauskatze zu uns in den WTV. Der selbstbewusste Kater ist durchaus zugänglich und genießt Streicheleinheiten, sobald er seine anfängliche Scheu abgelegt hat. Er möchte allerdings selbst bestimmen dürfen, wann er Zärtlichkeit einfordert. Ein auf dem Schoß sitzendes Schmusetier wird aus ihm jedoch nicht, da er es gar nicht mag, hochgehoben zu werden. Wird es ihm zu viel an Zärtlichkeit, so zieht er sich einfach zurück. Das sollten die Menschen dann auch respekti', 8, 'looking around', '2020-08-08', 'old', 1),
(5, 'Merlin', 'https://thenypost.files.wordpress.com/2019/07/don-pit-bull-shelter-dog-animal-care-center-brooklyn-heat-exhaustion.jpg?quality=80&strip=all&w=618&h=410&crop=1', 'Der junge Dobermann-Mischlingsrüde Merlin wurde bei uns abgegeben, weil seine ehemaligen Menschen überfordert mit ihm waren. Merlin dürfte in seinem bisherigen Leben nicht viel kennengelernt haben. Er ist ein freundlicher Hund - sowohl gegenüber Menschen, als auch gegenüber Hunden. Beim ersten Kontakt zeigt er sich ein wenig aufgeregt, kommt aber schnell wieder zur Ruhe. Bei direktem Hundekontakt (zB im Freilauf) zeigt sich Merlin nicht unverträglich, jedoch rüpelhaft. Durch Training mit souverä', 3, NULL, NULL, 'small', 2),
(6, 'Emma', 'https://d1wmhwtkksj55o.cloudfront.net/wp-content/uploads/2015/01/Shelter-dog-992x558.jpg', 'Die junge Mischlingshündin Emma wurde von der Straße gerettet und wuchs bis zu ihrem 6. Lebensmonat mit ihren Geschwistern in einer Scheune auf bevor sie zu uns kam. Entsprechend hat sie in ihrem bisherigen Leben nichts kennen gelernt und reagiert auf alles, was sie nicht kennt sehr ängstlich! Mit Artgenossen ist sie gut verträglich, Menschen gegenüber ist sie jedoch furchtsam, lässt sich nicht angreifen oder anleinen. Erschwerend ist auch die Tatsache, dass Emma eine gute Kletterkünstlerin ist ', 2, NULL, NULL, 'small', 2),
(7, 'Arnold', 'https://twistedsifter.files.wordpress.com/2017/08/reddit-fell-in-love-with-this-shelter-dog-and-he-just-found-his-forever-home-2.jpg', 'Der kleine Dackel-Mischlingsrüde Arnold benötigt bei Menschen lange eine Kennenlernphase, um Vertrauen aufzubauen, da er vor fremden Menschen wie auch lauten Geräuschen Angst hat. Mit Hündinnen verträgt er sich sehr gut, bei Rüden entscheidet die Sympathie. Da Arnold sehr unsicher ist und ohne einen zweiten Hund an seiner Seite keinen Schritt macht, suchen wir für den hübschen Kerl ein ruhiges Zuhause mit Garten im ländlichen Raum an der Seite eines souveränen Zweithundes. Arnold lässt sich noch', 2, NULL, NULL, 'small', 1),
(8, 'Leo', 'https://www.pasadenastarnews.com/wp-content/uploads/2019/04/A473131_Patches_Aust_Cattle_Dog_B-1.jpg?w=467', 'Der verspielte Labrador-Mischlingsrüde Leo ist sehr lieb zu Menschen und auch mit anderen Hunden gut verträglich. Der hübsche Kerl geht brav an der Leine und ist stubenrein. Leo lernt sehr rasch und gerne, ist in der Wohnung sehr brav und auch im Auto legt sich seine anfängliche Aufregung rasch. Zur Zeit erhält Leo noch Schmerzmedikamente und Physiotherapie, da sich sein Hinterbein nach einem Fenstersturz noch erholen muss! Sollte sein zukünftiges Zuhause in höheren Stockwerken sein oder über ei', 4, NULL, NULL, 'small', 1),
(9, 'Asasha', 'https://www.cesarsway.com/wp-content/uploads/2015/11/You-to-the-rescue-Starting-your-own-shelter.jpg', 'Die stattliche Am. Staffordshire Terrier-Hündin Akasha ist menschenfreundlich, nur anfangs etwas schüchtern. An der Leine geht sie brav an Artgenossen vorbei ohne sich aufzuregen, im Freilauf ist sie mit anderen Hunden gut verträglich. Die hübsche Hundedame ist stubenrein und sehr lebhaft. Das Gehen an der lockeren Leine möchte sie noch in kleinen Schritten erlernen.', 1, 'palying ball', NULL, 'large', 1),
(10, 'Casper', 'https://image.stern.de/9156004/16x9-940-529/d84aaf74ffcbcf84bb0e272390976980/sq/kleine-katze.jpg', 'Für den stattlichen Kater Casper suchen wir ein Zuhause bei Menschen mit Katzen-Erfahrung, da der hübsche Kerl eher ein Wildkater als eine Hauskatze ist. Casper lässt sich mittlerweile abends beim Spielen auch angreifen und streicheln, ansonsten ist dies aber nicht möglich, da er sehr verschreckt ist. Für ihn suchen wir ein Zuhause in Haus mit Garten. Ruhige, nette Katzen im neuen Zuhause stellen kein Problem dar, andere Tiere oder Kinder sollten jedoch nicht im selben Zuhause wohnen!', 4, 'looking around', NULL, 'large', 2),
(11, 'Shiwa', 'https://d17fnq9dkz9hgj.cloudfront.net/uploads/2012/11/136634315-adoptable-pet-photo-tips-632x475.jpg', 'Die junge Am. Staffordshire Terrier - Malinois - Mischlingshündin Shiva benötigt bei fremden Menschen eine Kennenlernphase, zeigt sich dann sehr anhänglich und verschmust. Da sie andere Hunde (sowohl im direkten Kontakt als auch an der Leine) sehr stressen, suchen wir für die hübsche Hündin ein ruhiges, stressfreies Zuhause ohne Kinder außerhalb der Stadt. Shiva ist altersbedingt noch sehr stürmisch, das Gehen an der lockeren Leine zählt nicht zu ihren Stärken, aber Shiva lernt sehr gerne und se', 2, 'palying ball', NULL, 'large', 2),
(12, 'Charlie', 'https://www.fressnapf.de/medias/katze-dick-400-214.jpg?context=bWFzdGVyfGltYWdlc3wzMjMxN3xpbWFnZS9qcGVnfGltYWdlcy9oNzQvaDcyLzk2NzE2MDQ4OTU3NzQuanBnfDQzMmQ5NjA3ZWZlMzcxOTU0MzkxMTY2NjJkYTIwOGE3Njk1M2ZlNjAwY2FhMmFlMmViZTRkNWIwYTgwYTYzNGM', 'Für den Kater Charlie suchen wir ein Zuhause bei Menschen mit Katzen-Erfahrung, da der hübsche Kerl eher ein Wildkater als eine Hauskatze ist. Charlie lässt sich mittlerweile abends beim Spielen auch angreifen und streicheln, ansonsten ist dies aber nicht möglich, da er sehr verschreckt ist. Für ihn suchen wir ein Zuhause in Haus mit Garten. Ruhige, nette Katzen im neuen Zuhause stellen kein Problem dar, andere Tiere oder Kinder sollten jedoch nicht im selben Zuhause wohnen!', 3, 'looking around', NULL, 'large', 1),
(19, '', '', 'dfffffffffffffffffffffffffffffffffffffffffffffffffffff', 0, '', '0000-00-00', 'old', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `members`
--

CREATE TABLE `members` (
  `id_members` int(11) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `pass` varchar(255) NOT NULL,
  `status` enum('user','admin') DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `members`
--

INSERT INTO `members` (`id_members`, `first_name`, `last_name`, `email`, `pass`, `status`) VALUES
(2, 'dfgsf', 'asdfasdf', 'flo.moerzinger@gmx.at', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'admin'),
(3, 'sdfsdf', 'dsfdffdfdf', 'f.moerzinger@gmx.at', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'user'),
(9, 'asdf', 'ddddddddd', 'code@gmx.at', '8d969eef6ecad3c29a3a629280e686cf0c3f5d5a86aff3ca12020c923adc6c92', 'user');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `shelter`
--

CREATE TABLE `shelter` (
  `id_shelter` int(11) NOT NULL,
  `shelter_name` varchar(100) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `ZIP` smallint(6) DEFAULT NULL,
  `image` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `shelter`
--

INSERT INTO `shelter` (`id_shelter`, `shelter_name`, `address`, `city`, `ZIP`, `image`) VALUES
(1, 'Shelter Innsbruck', 'Völser Straße 55', 'Innsbruck', 6020, 'https://www.google.com/search?q=tiere&tbm=isch&ved=2ahUKEwjhy4j7vr3oAhUSMRoKHUu7Bj0Q2-cCegQIABAA&oq=tiere&gs_lcp=CgNpbWcQAzICCAAyAggAMgUIABCDATICCAAyAggAMgIIADICCAAyAggAMgIIADICCAA6BAgAEENQktgBWOflAWCf7gFoAHAAeACAAW2IAeoHkgEEMTIuMZgBAKABAaoBC2d3cy13aXotaW1n&sclient=img&ei=NW5_XqHdB5LiaMv2mugD#imgrc='),
(2, 'Shelter Wien', 'Triester Straße 8', 'Vösendorf', 2331, 'https://sskm.sparkasseblog.de/files/2017/12/33665285.jpg');

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `animals`
--
ALTER TABLE `animals`
  ADD PRIMARY KEY (`id_animals`),
  ADD KEY `fk_shelter` (`fk_shelter`);

--
-- Indizes für die Tabelle `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`id_members`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indizes für die Tabelle `shelter`
--
ALTER TABLE `shelter`
  ADD PRIMARY KEY (`id_shelter`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `animals`
--
ALTER TABLE `animals`
  MODIFY `id_animals` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT für Tabelle `members`
--
ALTER TABLE `members`
  MODIFY `id_members` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT für Tabelle `shelter`
--
ALTER TABLE `shelter`
  MODIFY `id_shelter` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `animals`
--
ALTER TABLE `animals`
  ADD CONSTRAINT `animals_ibfk_1` FOREIGN KEY (`fk_shelter`) REFERENCES `shelter` (`id_shelter`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
